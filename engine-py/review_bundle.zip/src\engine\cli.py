"""Command line: `uv run engine download|clean|backtest [--unlock-holdout --reason "..."]`."""

from __future__ import annotations

import argparse

from engine.pipeline import load_config, run_pipeline


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(prog="engine")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("download", help="download raw history from data.binance.vision")
    sub.add_parser("clean", help="clean raw data into data/cleaned")
    bt = sub.add_parser("backtest", help="run strategies, validation and build the HTML report")
    bt.add_argument("--unlock-holdout", action="store_true", help="include locked holdout (logged)")
    bt.add_argument("--reason", default="", help="why the holdout is being unlocked")
    a = p.parse_args(argv)

    if a.cmd in ("download", "clean"):
        from engine.data.cli_data import run_clean, run_download

        (run_download if a.cmd == "download" else run_clean)(load_config("universe.yaml"))
    else:
        path = run_pipeline(unlock_holdout=a.unlock_holdout, reason=a.reason)
        print(f"Report written: {path}")


if __name__ == "__main__":
    main()
