"""Delta-neutral funding carry: long spot / short perp when trailing funding APR is high."""

from __future__ import annotations

from typing import Any

import pandas as pd

from engine.contracts import Dataset, TargetWeights
from engine.signals.trend import decision_times, tradable_mask


class CarryStrategy:
    name = "carry"

    def __init__(self, params: dict[str, Any]):
        self.params = params
        self.entry = float(params["entry_funding_annual"])
        self.exit = float(params["exit_funding_annual"])
        self.lookback_h = int(params["funding_lookback_hours"])
        self.max_w = float(params["max_weight_per_asset"])
        self.max_gross = float(params["max_gross"])
        self.rebalance_hours = int(params.get("rebalance_hours", 8))
        # Spot and perp must be the SAME asset: skip if basis exceeds this (e.g. relaunched tickers).
        self.max_basis = float(params.get("max_basis", 0.02))

    def trailing_apr(self, funding: pd.DataFrame, t: pd.Timestamp) -> pd.Series:
        """Mean funding over events in (t - lookback, t], annualised (3 events/day)."""
        win = funding.loc[(funding.index > t - pd.Timedelta(hours=self.lookback_h)) & (funding.index <= t)]
        return win.mean() * 3 * 365

    def target_weights(self, data: Dataset) -> TargetWeights:
        idx = data.perp.close.index.union(data.spot.close.index)
        symbols = sorted(set(data.spot.close.columns) & set(data.perp.close.columns))
        times = decision_times(pd.DatetimeIndex(idx), self.rebalance_hours)
        ok = (
            tradable_mask(data.spot).reindex(index=idx, columns=symbols).fillna(False).astype(bool)
            & tradable_mask(data.perp).reindex(index=idx, columns=symbols).fillna(False).astype(bool)
        )
        basis = (
            data.spot.close.reindex(index=idx, columns=symbols)
            / data.perp.close.reindex(index=idx, columns=symbols)
            - 1.0
        ).abs()
        ok = ok & (basis <= self.max_basis).fillna(False)
        funding = data.funding.reindex(columns=symbols)
        active = dict.fromkeys(symbols, False)
        rows = []
        for t in times:
            apr = self.trailing_apr(funding, t)
            for s in symbols:
                a = apr.get(s)
                if not bool(ok.at[t, s]) or a is None or pd.isna(a):
                    active[s] = False
                elif active[s]:
                    active[s] = bool(a >= self.exit)
                else:
                    active[s] = bool(a > self.entry)
            on = [s for s in symbols if active[s]]
            w = min(self.max_w, (self.max_gross / 2) / len(on)) if on else 0.0
            rows.append({s: (w if active[s] else 0.0) for s in symbols})
        spot = pd.DataFrame(rows, index=times, columns=symbols, dtype=float)
        return TargetWeights(spot=spot, perp=-spot)
