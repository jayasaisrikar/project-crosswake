"""Build enabled strategies from the experiment config."""

from __future__ import annotations

from typing import Any

from engine.contracts import Strategy
from engine.signals.carry import CarryStrategy
from engine.signals.trend import TrendStrategy

_REGISTRY: dict[str, type] = {"trend": TrendStrategy, "carry": CarryStrategy}


def build_strategies(exp_cfg: dict[str, Any]) -> list[Strategy]:
    out: list[Strategy] = []
    for name, params in exp_cfg.get("strategies", {}).items():
        if name in _REGISTRY and isinstance(params, dict) and params.get("enabled", False):
            out.append(_REGISTRY[name](params))
    return out
