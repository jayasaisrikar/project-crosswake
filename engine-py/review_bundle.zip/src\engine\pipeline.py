"""End-to-end research pipeline: load data -> run strategies -> validate -> report.

Integrity rules enforced here:
  * Development runs stop at split.dev_end. The holdout period is only evaluated with unlock_holdout=True,
    and every unlock is permanently logged (experiments/holdout_log.jsonl).
  * Every run (including parameter variants) is appended to the experiment registry, so the deflated
    Sharpe uses the honest number of trials.
  * Results are re-run at 1.0x / 1.5x / 2.0x costs.
"""

from __future__ import annotations

import copy
import hashlib
import json
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

from engine.backtest.engine import run_backtest
from engine.backtest.portfolio import benchmark_buy_hold, combine
from engine.contracts import BacktestResult, Dataset
from engine.costs import CostModel
from engine.data.load import load_dataset
from engine.reporting.csv_export import export_tables
from engine.reporting.html_report import build_report
from engine.signals.registry import build_strategies
from engine.validation import metrics, stats
from engine.validation.walkforward import ExperimentRegistry, HoldoutLock, walk_forward_splits

ROOT = Path(__file__).resolve().parents[2]


def load_config(name: str) -> dict[str, Any]:
    with open(ROOT / "config" / name, encoding="utf-8") as f:
        return yaml.safe_load(f)


def git_sha() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT, text=True,
                                       stderr=subprocess.DEVNULL).strip()
    except Exception:
        return "uncommitted"


def data_hash(root: Path) -> str:
    audit = root / "audit.json"
    return hashlib.sha256(audit.read_bytes()).hexdigest()[:12] if audit.exists() else "unknown"


def _daily(returns: pd.Series) -> pd.Series:
    return (1 + returns).resample("1D").prod() - 1


def run_all(cost_multiplier: float, data: Dataset, exp: dict, start, end) -> dict[str, BacktestResult]:
    cost_cfg = copy.deepcopy(exp["costs"])
    cost_cfg["stress_multiplier"] = cost_cfg.get("stress_multiplier", 1.0) * cost_multiplier
    cm = CostModel.from_config(cost_cfg)
    cap = float(exp["initial_capital"])
    alloc = exp["strategies"]["allocation"]
    sleeves: dict[str, BacktestResult] = {}
    for strat in build_strategies(exp):
        sleeves[strat.name] = run_backtest(
            strat, data, cm, cap * alloc.get(strat.name, 0.0), start=start, end=end, name=strat.name
        )
    out: dict[str, BacktestResult] = {"Combined": combine(sleeves, alloc, cap)}
    out.update({k.capitalize(): v for k, v in sleeves.items()})
    out["BTC buy&hold"] = benchmark_buy_hold(data, "BTC", "spot", cap, cm, start=start, end=end)
    return out


def trend_trial_grid(exp: dict) -> list[dict]:
    """Small, pre-declared parameter grid (all variants count as trials for DSR / PBO)."""
    base = exp["strategies"]["trend"]
    grid = []
    for lbs in ([20, 60, 120], [10, 30, 90], [30, 90, 180]):
        for vt in (0.15, 0.20, 0.30):
            p = dict(base, lookbacks_days=lbs, vol_target_annual=vt)
            grid.append(p)
    return grid


def run_pipeline(unlock_holdout: bool = False, reason: str = "", out_dir: str = "reports") -> Path:
    uni, exp = load_config("universe.yaml"), load_config("experiment.yaml")
    data_root = ROOT / "data" / "cleaned"
    data = load_dataset(str(data_root), symbols=uni["symbols"])

    lock = HoldoutLock(exp["split"]["holdout_start"],
                       log_path=str(ROOT / "experiments" / "holdout_log.jsonl"))
    if unlock_holdout:
        lock.unlock(reason or "final evaluation")
    end = None if unlock_holdout else pd.Timestamp(exp["split"]["dev_end"], tz="UTC") + pd.Timedelta(hours=23)
    if end is not None:
        data = data.truncate(end)
    lock.check(data.perp.close)

    registry = ExperimentRegistry(str(ROOT / "experiments" / "registry.jsonl"))
    sha, dh = git_sha(), data_hash(data_root)

    # 1) Main results at 1x costs + stress
    results = run_all(1.0, data, exp, None, end)
    stress_rows = {}
    for mult in (1.0, 1.5, 2.0):
        rs = results if mult == 1.0 else run_all(mult, data, exp, None, end)
        s = metrics.performance_summary(rs["Combined"].returns)
        stress_rows[f"{mult:.1f}x costs"] = {k: s.get(k) for k in ("cagr", "sharpe", "max_drawdown")}
    stress = pd.DataFrame(stress_rows).T

    # 2) Trial grid for trend (registered) -> DSR + PBO
    from engine.signals.trend import TrendStrategy

    cm = CostModel.from_config(exp["costs"])
    trial_rets = {}
    for i, p in enumerate(trend_trial_grid(exp)):
        cap0 = float(exp["initial_capital"])
        r = run_backtest(TrendStrategy(p), data, cm, cap0, end=end, name=f"trend_{i}")
        d = _daily(r.returns)
        trial_rets[f"trend_{i}"] = d
        registry.log(strategy="trend", params=p, metrics=metrics.performance_summary(r.returns),
                     data_hash=dh)
    trial_df = pd.DataFrame(trial_rets).dropna()
    trial_sharpes = [float(c.mean() / c.std()) for _, c in trial_df.items() if c.std() > 0]

    comb_daily = _daily(results["Combined"].returns).dropna()
    bench_daily = _daily(results["BTC buy&hold"].returns).reindex(comb_daily.index).fillna(0)
    robust = {
        "hac_tstat": stats.sharpe_hac_tstat(comb_daily),
        "bootstrap_sharpe_ci": stats.block_bootstrap_ci(
            comb_daily, lambda x: x.mean() / x.std() * (365**0.5), seed=7),
        "dsr_trend": stats.deflated_sharpe(_daily(results["Trend"].returns).dropna(), trial_sharpes),
        "pbo_trend": stats.pbo_cscv(trial_df, S=16)["pbo"],
        "spa_vs_btc": stats.spa_test(trial_df.reindex(comb_daily.index).fillna(0), bench_daily),
        "n_trials": len(trial_sharpes),
    }

    # 3) Walk-forward of the combined portfolio (parameters fixed; reports per-fold OOS performance)
    wf_rows = []
    comb_ret = results["Combined"].returns
    idx = pd.DatetimeIndex(comb_ret.index)
    for tr_pos, te_pos in walk_forward_splits(idx, exp["walk_forward"]["train_months"],
                                      exp["walk_forward"]["test_months"],
                                      exp["walk_forward"]["embargo_bars"]):
        tr, te = idx[tr_pos], idx[te_pos]
        s = metrics.performance_summary(comb_ret.loc[te[0]:te[-1]])
        wf_rows.append({"train": f"{tr[0]:%Y-%m}→{tr[-1]:%Y-%m}", "test": f"{te[0]:%Y-%m}→{te[-1]:%Y-%m}",
                        "test_return": s.get("total_return"), "test_sharpe": s.get("sharpe")})

    for name, r in results.items():
        registry.log(strategy=name, params=exp["strategies"], metrics=metrics.performance_summary(r.returns),
                     data_hash=dh)

    ctx = {
        "title": "Systematic Crypto Engine — Backtest Report"
                 + (" (incl. HOLDOUT)" if unlock_holdout else " (development period)"),
        "generated_at": datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC"),
        "data_range": f"{comb_ret.index.min():%Y-%m-%d} → {comb_ret.index.max():%Y-%m-%d}",
        "universe": uni["symbols"],
        "git_sha": sha,
        "params": exp,
        "results": results,
        "summaries": {k: metrics.performance_summary(v.returns, v.trades) for k, v in results.items()},
        "monthly": {k: metrics.monthly_returns(v.returns) for k, v in results.items()},
        "yearly": {k: metrics.yearly_returns(v.returns) for k, v in results.items()},
        "stress": stress,
        "walk_forward": pd.DataFrame(wf_rows),
        "oos_label": {"in_sample_end": exp["split"]["dev_end"],
                      "holdout_start": exp["split"]["holdout_start"]},
        "stats": robust,
        "notes": [
            "Fills at next 1h bar open after the decision bar; taker fees, half-spread, sqrt impact.",
            "Spreads are configured estimates, not measured historical quotes.",
            "Universe picked in 2026 includes LUNA and FTT but is still partly survivorship-biased.",
            "Exchange/counterparty failure (e.g. FTX 2022) is not modeled; carry assumes Binance solvency.",
            "Past performance does not guarantee future results. Not investment advice.",
        ],
    }
    out = ROOT / out_dir
    out.mkdir(exist_ok=True)
    tag = "holdout" if unlock_holdout else "dev"
    html = build_report(ctx, str(out / f"report_{tag}.html"))
    export_tables(ctx, str(out / f"tables_{tag}"))
    (out / f"stats_{tag}.json").write_text(json.dumps(robust, default=str, indent=2), encoding="utf-8")
    return Path(html)
