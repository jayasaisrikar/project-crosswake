from __future__ import annotations

import math

import numpy as np
import pandas as pd
import pytest

from engine.contracts import MarketData
from engine.costs import CostModel, rolling_adv_and_vol

CFG = {"fee_bps": {"spot": 10.0, "perp": 5.0}, "half_spread_bps": {"BTC": 0.5, "default": 2.0},
       "impact_y": 0.7, "stress_multiplier": 1.0}


def test_fee_and_spread_linear() -> None:
    m = CostModel.from_config(CFG)
    a = m.trade_cost("BTC", "spot", 1000, 50000, 1e12, 0.03)
    b = m.trade_cost("BTC", "spot", 2000, 50000, 1e12, 0.03)
    assert a.fees == pytest.approx(1.0)
    assert a.spread == pytest.approx(0.05)
    assert b.fees == pytest.approx(2 * a.fees)
    assert b.spread == pytest.approx(2 * a.spread)
    c = m.trade_cost("XYZ", "perp", 1000, 1, 1e12, 0.03)
    assert c.spread == pytest.approx(0.2)
    assert c.fees == pytest.approx(0.5)


def test_impact_sqrt_scaling() -> None:
    m = CostModel.from_config(CFG)
    a = m.trade_cost("BTC", "perp", 1e4, 1, 1e8, 0.03)
    b = m.trade_cost("BTC", "perp", 4e4, 1, 1e8, 0.03)
    assert a.impact == pytest.approx(0.7 * 0.03 * math.sqrt(1e-4) * 1e4)
    assert b.impact / 4e4 == pytest.approx(2 * a.impact / 1e4)


def test_multiplier_scales_all() -> None:
    base = CostModel.from_config(CFG).trade_cost("ETH", "spot", 5e4, 1, 1e7, 0.04)
    s = CostModel.from_config(CFG, multiplier=2.0).trade_cost("ETH", "spot", 5e4, 1, 1e7, 0.04)
    assert s.fees == pytest.approx(2 * base.fees)
    assert s.spread == pytest.approx(2 * base.spread)
    assert s.impact == pytest.approx(2 * base.impact)
    assert s.total == pytest.approx(2 * base.total)


@pytest.mark.parametrize("adv", [None, 0.0, float("nan")])
def test_missing_adv_is_conservative(adv) -> None:
    m = CostModel.from_config(CFG)
    liquid = m.trade_cost("ETH", "perp", 1e4, 1, 1e8, 0.04)
    missing = m.trade_cost("ETH", "perp", 1e4, 1, adv, 0.04)
    assert missing.impact > 10 * liquid.impact
    assert missing.impact == pytest.approx(0.7 * 0.04 * 1e4)


def test_rolling_adv_vol_causal() -> None:
    idx = pd.date_range("2024-01-01", periods=500, freq="h", tz="UTC")
    rng = np.random.default_rng(0)
    close = pd.DataFrame({"A": 100 * np.exp(np.cumsum(rng.normal(0, 0.01, 500)))}, index=idx)
    qv = pd.DataFrame({"A": rng.uniform(1, 2, 500)}, index=idx)
    filled = pd.DataFrame(False, index=idx, columns=["A"])
    md = MarketData(close, close, close, close, qv, qv, filled)
    adv, vol = rolling_adv_and_vol(md, days=5)
    t = idx[300]
    adv2, vol2 = rolling_adv_and_vol(md.truncate(t), days=5)
    assert adv.loc[t, "A"] == adv2.loc[t, "A"]
    assert vol.loc[t, "A"] == vol2.loc[t, "A"]
    qv3 = qv.copy()
    qv3.loc[t, "A"] = 1e9  # bar t itself must not leak into the value at t
    md3 = MarketData(close, close, close, close, qv3, qv3, filled)
    assert rolling_adv_and_vol(md3, days=5)[0].loc[t, "A"] == adv.loc[t, "A"]
    assert adv.loc[t, "A"] == pytest.approx(qv["A"].iloc[300 - 120:300].mean() * 24)
