"""Transaction cost model: fees + half-spread + square-root market impact."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from engine.contracts import CostBreakdown, Market, MarketData

MAX_PARTICIPATION = 1.0          # cap on notional / ADV used in the impact formula
DEFAULT_DAILY_VOL = 0.05         # conservative fallback when vol is unknown


@dataclass(frozen=True)
class CostModel:
    fee_bps: dict[str, float]
    half_spread_bps: dict[str, float]
    impact_y: float
    multiplier: float = 1.0
    max_participation: float = MAX_PARTICIPATION
    default_daily_vol: float = DEFAULT_DAILY_VOL
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_config(cls, costs_cfg: dict[str, Any], multiplier: float | None = None) -> CostModel:
        mult = float(costs_cfg.get("stress_multiplier", 1.0)) if multiplier is None else float(multiplier)
        return cls(
            fee_bps={k: float(v) for k, v in costs_cfg["fee_bps"].items()},
            half_spread_bps={k: float(v) for k, v in costs_cfg["half_spread_bps"].items()},
            impact_y=float(costs_cfg["impact_y"]),
            multiplier=mult,
        )

    def with_multiplier(self, multiplier: float) -> CostModel:
        return CostModel(self.fee_bps, self.half_spread_bps, self.impact_y, float(multiplier),
                         self.max_participation, self.default_daily_vol, self.extra)

    def half_spread(self, symbol: str) -> float:
        return self.half_spread_bps.get(symbol, self.half_spread_bps.get("default", 0.0))

    def trade_cost(
        self,
        symbol: str,
        market: Market,
        notional_abs: float,
        price: float,
        adv_quote: float | None,
        daily_vol: float | None,
    ) -> CostBreakdown:
        """Cost in quote currency (USDT) of trading `notional_abs`. `price` kept for API symmetry."""
        n = abs(float(notional_abs))
        if n == 0.0:
            return CostBreakdown()
        fees = self.fee_bps[market] * 1e-4 * n
        spread = self.half_spread(symbol) * 1e-4 * n
        vol = daily_vol if daily_vol is not None and math.isfinite(daily_vol) and daily_vol > 0 \
            else self.default_daily_vol
        if adv_quote is None or not math.isfinite(adv_quote) or adv_quote <= 0:
            participation = self.max_participation  # unknown liquidity: assume worst case
        else:
            participation = min(n / adv_quote, self.max_participation)
        impact = self.impact_y * vol * math.sqrt(participation) * n
        m = self.multiplier
        return CostBreakdown(fees=fees * m, spread=spread * m, impact=impact * m)


def rolling_adv_and_vol(md: MarketData, days: int = 30) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Causal ADV (quote, per day) and daily vol. Value at t uses bars strictly before t."""
    window = days * 24
    minp = 24
    qv = md.quote_volume.where(~md.is_filled.fillna(False).astype(bool))
    adv = qv.rolling(window, min_periods=minp).mean() * 24
    rets = md.close.pct_change(fill_method=None).replace([np.inf, -np.inf], np.nan)
    vol = rets.rolling(window, min_periods=minp).std() * math.sqrt(24)
    return adv.shift(1), vol.shift(1)
